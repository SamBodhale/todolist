# TriklAssignment
<br>
<br>
<br>

## Option 1 

### Deploy Link - https://option1-gamma.vercel.app/

### Glimpse of My work :-

<br>


![Line](https://github.com/lokeshahire/TriklAssignment/blob/master/option1/images/opt1.png?raw=true)
<br>
<br>
<br>

<br>





## Option 2

### Glimpse of My work :-
### Deploy Link - https://triklassignmentbackend.onrender.com/


<br>
<br>
<br>

<br>



## Option 3
### Deploy Link - https://option3.vercel.app/

### Glimpse of My work :-

<br>


![Line](https://github.com/lokeshahire/TriklAssignment/blob/master/option1/images/opt3.png?raw=true)
<br>
<br>
<br>

<br>


### To Start This Project 

<br>

1. npm run start
<br>

2. Runs the app in the development mode
Open [http://localhost:3000](http://localhost:3000) to view it in the browser.




Thank You :)
